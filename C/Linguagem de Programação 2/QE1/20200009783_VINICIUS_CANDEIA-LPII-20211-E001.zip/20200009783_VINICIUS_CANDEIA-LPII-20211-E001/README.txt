 - Para compilar:
	Necessário algum ambiente POSIX com o gcc instalado.
	No terminal: gcc qe.c aditivos.c -o qe -pthread
	Onde:
		qe.c .......... -> arquivo do código que atende à questão passada;
		aditivos.c .... -> funções extras que o criador gosta de usar;
		qe ............ -> nome do executável que será criado.

 - Para executar:
	No terminal: ./qe [ -p || -t ] x y
	Onde:
		./qe .. -> nome do executável;
		-p .... -> usando processos;
		-t .... -> usando threads;
		x ..... -> número de lebres que participará da corrida;
		y ..... -> tamanho da pista.

Alterações pariculares que fiz:
	1 : Tanto a função para as threads, como a função para os processos estão
		recebendo um único parâmetro.
	2 : O parâmetro recebido é uma struct contendo 3 variáveis:
        	1 ) O índice da lebre
            	2 ) O salto máximo que a lebre pode dar
            	3 ) O tamanho da pista -> como a lebre saberia se ganhou se não sabe
                                      	  onde termina a pista?
	3 : O salto e o tamanho da pista estão em centímetros.

Dúvidas que tive:
	1 : O salto máximo de cada coelho é algo fixo? Ou seria necessário
            gerar um valor aleatório?
	    Fiz como algo fixo.
