#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <locale.h>
#include <sys/types.h>
#include <time.h>
#include <wchar.h>
#include <string.h>

#include "aditivos.h"

// * Bibliotecas Linux
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <semaphore.h>

#define QUANTIDADE_CLIENTES 8
#define TAMANHO_MENSAGEM 100

pthread_mutex_t travaSoma = PTHREAD_MUTEX_INITIALIZER;

int contadorClientes = 0;

/*
    (Questão 1 - 10 pontos) Faça um programa em C/C++ que crie um servidor TCP que
    atenda os requisitos listados a seguir.

        1) Trate até 8 conexões simultâneas de clientes na porta 9900;

        2) Cada novo cliente deve receber uma string de boas vindas ao se conectar ao
        servidor (“WELCOME”);

        3) O servidor tratará strings enviadas pelos clientes como comandos, e
        retornára o resultado para eles de acordo com os comandos, como descrito a
        seguir. Os seguintes comandos devem ser suportados:

            a) "RNDNUM\n" - o servidor irá gerar e retornar um valor aleatório
                entre 0 e 1000;

            b) "CRTIME\n" - o servidor retornará a data e hora corrente;

            c) "FINISH\n" - o servidor finaliza a conexão do cliente;

            d) "SHTDWN\n" - o servidor é finalizado (fim do programa);

        4) O servidor deverá armazenar todas as solicitações realizadas pelos clientes
        em um arquivo de texto chamado "log.txt". O acesso de escrita e leitura a esse
        arquivo deverá ser feito através de um monitor.

    A saída do seu programa deve ser bem planejada, de forma a mostrar o que está
    acontecendo em cada momento relevante. Teste o servidor com múltiplos clientes,
    usando instâncias de telnet ou nc (netcat).
*/

typedef struct monitor
{
    sem_t mutex;
} Monitor;

Monitor monitorArquivo;

void funcaoArquivo(char *mensagem, int tamanhoMensagem)
{
    wprintf(L".\n");
    
    sem_wait(&monitorArquivo.mutex);

    char escrita[tamanhoMensagem];
    strncpy(escrita, mensagem, tamanhoMensagem);

    wprintf(L".\n");

    FILE *meuArquivo;
    if (meuArquivo = fopen("log.txt", "r")){
        fclose(meuArquivo);
        meuArquivo = fopen("log.txt", "a");
    } else {
        meuArquivo = fopen("log.txt", "w");
    }

    wprintf(L".\n");

    fprintf(meuArquivo, "%s \n", escrita);

    fclose(meuArquivo);

    sem_post(&monitorArquivo.mutex);
}

void *funcaoCliente(void *valor)
{
    int resultado;
    int numero;

    int meuClienteFuncao = (int)valor;

    char *mensagemInicial = "Bem-Vindo! \n";
    resultado = write(meuClienteFuncao, mensagemInicial, strlen(mensagemInicial));

    while (true)
    {
        char buffer[TAMANHO_MENSAGEM];

        bzero(&buffer, sizeof(buffer));

        // & Recebendo o comando
        resultado = recv(meuClienteFuncao, buffer, TAMANHO_MENSAGEM, 0);
        wprintf(corAzul L"[C]" corBranca " >> Comando : " corAzul "%s \n", buffer);

        char mensagemServidor[TAMANHO_MENSAGEM];
        bzero(&mensagemServidor, strlen(mensagemServidor));

        if (strncmp("RNDNUM", buffer, 6) == 0)
        {
            srand(time(NULL) ^ (getpid() << 16));
            numero = rand() % 1000;
            sprintf(mensagemServidor, "%d \n", numero);
        }
        else if (strncmp("CRTIME", buffer, 6) == 0)
        {
            struct tm *ponteiro;
            time_t segundos;

            time(&segundos);
            ponteiro = localtime(&segundos);

            sprintf(mensagemServidor, "%d:%d || %d / %d / %d \n", ponteiro->tm_hour, ponteiro->tm_min, ponteiro->tm_mday, ponteiro->tm_mon + 1, ponteiro->tm_year + 1900);
        }
        else if (strncmp("FINISH", buffer, 6) == 0)
        {
            traco(1);
            close(meuClienteFuncao);
            break;
        }
        else if (strncmp("SHTDWN", buffer, 6) == 0)
        {
            exit(0);
        }
        else
        {
            sprintf(mensagemServidor, "ERROR \n");
        }

        resultado = write(meuClienteFuncao, mensagemServidor, strlen(mensagemServidor));

        wprintf(L".\n");
        funcaoArquivo(&mensagemServidor, strlen(mensagemServidor));
        wprintf(L".\n");

        if (resultado > 0)
        {
            wprintf(corVerde L"[S]" corBranca " >> %s", mensagemServidor);
        }

        traco(1);
    }
}

int main()
{

    inicioCodigo();

    int meuSocket;
    int meuCliente[QUANTIDADE_CLIENTES];
    int portaServidor;
    int resultado;
    int tamanhoCliente[QUANTIDADE_CLIENTES];
    int indexCliente = 0;

    struct sockaddr_in informacaoCliente[QUANTIDADE_CLIENTES];
    struct sockaddr_in informacaoServidor;

    char mensagemServidor[TAMANHO_MENSAGEM];
    char mensagemRecebida[TAMANHO_MENSAGEM];

    pthread_t pthreadCliente[QUANTIDADE_CLIENTES];

    // | Pegando a porta
    wprintf(L"Porta: >> " corAmarela);
    wscanf(L"%d", &portaServidor);
    // srand(time(NULL));
    // portaServidor = rand() % 10 + 7770;
    traco(1);

    // | Criando o socket (TCP)
    meuSocket = socket(PF_INET, SOCK_STREAM, 0);

    if (meuSocket == -1)
    {
        wprintf(corVermelha L"Socket não criado!" corBranca);
        traco(2);
        exit(0);
    }

    // | Limpar memória da struct
    bzero(&informacaoServidor, sizeof(informacaoServidor));
    for (int i = 0; i < QUANTIDADE_CLIENTES; i++)
    {
        bzero(&informacaoCliente[i], sizeof(informacaoCliente[i]));
    }

    // | Definindo as características do socket
    informacaoServidor.sin_family = AF_INET;
    informacaoServidor.sin_addr.s_addr = htonl(INADDR_ANY);
    informacaoServidor.sin_port = htons(portaServidor);

    // | Conexão ao servidor (Bind)
    resultado = bind(meuSocket, &informacaoServidor, sizeof(informacaoServidor));

    if (resultado == -1)
    {
        wprintf(corVermelha L"Não conectado!" corBranca);
        traco(2);
        exit(0);
    }

    wprintf(corVerde L"Aguardando!" corBranca "\n");
    wprintf(L"Porta: " corAmarela "%d" corBranca "\n", portaServidor);
    traco(1);

    // | Listen
    resultado = listen(meuSocket, QUANTIDADE_CLIENTES);

    if (resultado == -1)
    {
        wprintf(corVermelha L"listen() falhou!" corBranca);
        traco(2);
        exit(0);
    }

    wprintf(L"... \n");

    // | Accept
    while (meuCliente[indexCliente] = accept(meuSocket,
                                             (struct sockaddr *)&informacaoCliente[indexCliente],
                                             &tamanhoCliente[indexCliente]))
    {
        wprintf(corVerde L"Conectado!" corBranca "\n");
        char *enderecoIPCliente = inet_ntoa(informacaoCliente[contadorClientes].sin_addr);
        wprintf(L"Endereço: " corAmarela "%s" corBranca, enderecoIPCliente);
        traco(2);

        pthread_create(&pthreadCliente[indexCliente], NULL, funcaoCliente, (void *)meuCliente[indexCliente]);

        if (meuCliente[contadorClientes] == -1)
        {
            wprintf(corVermelha L"accept() falhou!" corBranca);
            traco(2);
            exit(0);
        }

        indexCliente += 1;
        contadorClientes += 1;
        indexCliente = indexCliente % 10;

        wprintf(L"Conectados: " corAmarela "%d" corBranca, indexCliente);
        traco(2);
    }

    traco(2);
    return 0;
}