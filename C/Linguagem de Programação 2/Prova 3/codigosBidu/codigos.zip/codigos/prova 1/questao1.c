#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/wait.h>

#define QTD_LETRAS 26
#define DIC_NAME "dic.txt"

void* gera_dic_thread(void*) {
	return 0;
}

int gera_dic_proc(char c) {
	return 0;
} 

int main(void) {
	char opcao;
	pthread_t threads[QTD_LETRAS];
	int child_pids[QTD_LETRAS];
	int pid_original;

	pid_original = getpid();


	opcao = 't';

	if (opcao == 't') {
		//execucao com threads
		for (long i = 0; i < QTD_LETRAS; i++) {
			pthread_create(
				&threads[i], NULL, gera_dic_thread,(void*)i);
		}
		for (int i = 0; i < QTD_LETRAS; i++) {
			pthread_join(threads[i], NULL);
		}

		char letra = 'A';
		for (int i = 0; i < QTD_LETRAS; i++) {
			char filename[10];
			FILE* textfile;
			FILE* dicfile;
			sprintf(filename, "%c.txt", letra+i);
			textfile = fopen(filename, "r");
			dicfile = fopen(DIC_NAME, "w");
			//leio de textfile e escrevo em dicfile
		} 

	} else if (opcao == 'p') { 
		//execucao com processos
			for (int i = 0; i < QTD_LETRAS; i++) {
				if (getpid() == pid_original) {
					int fork_return;
					fork_return = fork();
					if (fork_return == 0) {
						//processo clonado
						char c = 'A';
						gera_dic_proc(c + i);
						exit(0);
					} else {
						//processo original
						child_pids[i] = fork_return;
					}
				}
			}
			for (int i = 0; i < QTD_LETRAS; i++) {
				waitpid(child_pids[i], NULL, NULL);
			}
			//TODOS CLONADOS ACABARAM

			//junta todos os arquivos em um

	} else if { 
		printf("Opcao invalida!");
		exit(0);
	}

	return 0;

}
